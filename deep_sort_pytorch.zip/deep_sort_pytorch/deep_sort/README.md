# Deep Sort 

This is the implemention of deep sort with pytorch.